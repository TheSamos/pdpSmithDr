/*
  Copyright (C) 2011 The SmithDR team, smithdr@labri.fr

  This file is part of SmithDR.

  SmithDR is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation, either version 3 of
  the License, or (at your option) any later version.

  SmithDR is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with SmithDR.
  If not, see <http://www.gnu.org/licenses/>.
*/

#include <core/mesh/MeshView.hpp>
#include <core/mesh/MeshView_.hpp>
#include <frontend/lib/Loader.hpp>
#include <frontend/lib/LoaderManager.hpp>

#include <frontend/lib/AlgorithmInfo.hpp>
#include <frontend/lib/Parameter.hpp>
#include <PluginDefs.hpp>
#include <Types.hpp>

#include "LoaderAsc.hpp"
#include "LoaderAsc.hxx"

#include <iostream>
#include <fstream>
#include <string>

template<typename T, unsigned int N>
class LoaderAscPlugin : public sd::frontend::Loader
{

public:

  LoaderAscPlugin()
    : sd::frontend::Loader(m_name, m_output, m_parameters)
  {
  }

  virtual ~LoaderAscPlugin()
  {
#ifdef DEBUG
    std::cout << "~" << m_name << std::endl;
#endif
  }

  virtual const std::string&
  name() const
  {
    return m_name;
  }

  virtual LoaderAscPlugin*
  clone()
  {
    return new LoaderAscPlugin;
  }

  virtual const std::string&
  formatName() const
  {
    static const std::string fName = "Asc format";
    return fName;
  }

  virtual const std::string&
  fileExtensionFilters() const
  {
    static const std::string ext = "*.asc";
    return ext;
  }

  virtual Loader::Type
  loaderType() const
  {
    return Loader::MeshLoader;
  }

  virtual bool
  load()
  {
    std::string filename = "";
    sd::frontend::Parameter p;
    this->getParams("filename", p);
    if (p.isString())
      filename = p.getAs<std::string>();
    if (filename.empty())
      return false;

    sd::asc::LoaderAsc<T, N> loader;
    sd::core::MeshView_<T, N>* img = loader.loadAsc(filename);
    if (!img)
      return false;
	
    img->addParent(this);
    return true;
  }

private:
  static const std::string m_name;
  static const sd::frontend::AlgorithmInfo m_output;
  static const sd::frontend::ParameterList m_parameters;
};

template<typename T, unsigned int N> const std::string LoaderAscPlugin<T, N>::m_name = "LoaderAscPlugin";
template<typename T, unsigned int N> const sd::frontend::AlgorithmInfo LoaderAscPlugin<T, N>::m_output = sd::frontend::make_info((sd::core::MeshView *) 0);
template<typename T, unsigned int N> const sd::frontend::ParameterList LoaderAscPlugin<T, N>::m_parameters = sd::frontend::make_parameter_list("filename", "");

// Register our plugin
extern "C"
SMITHDR_PLUGIN_API
void
registerPlugin()
{
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::DOUBLE, 3>);
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::DOUBLE, 4>);
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::FLOAT, 3>);
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::FLOAT, 4>);
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::INT, 3>);
  sd::frontend::registerLoader(new LoaderAscPlugin<sd::INT, 4>);
}
